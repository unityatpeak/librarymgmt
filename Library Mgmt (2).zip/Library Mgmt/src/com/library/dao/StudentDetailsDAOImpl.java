package com.library.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import com.library.bean.Student;
import com.library.util.DBConnection;

public class StudentDetailsDAOImpl implements StudentDetailsDAO{
	
	@Override
	public Boolean addStudentDetails(Student student) throws ClassNotFoundException, IOException, SQLException {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.addstudentdetails);
			
			
			preparedStatement.setString(1, student.getStu_name());
			preparedStatement.setInt(2, student.getStu_id());
			preparedStatement.setDate(3, new java.sql.Date(student.getIssue_date().getTime()));
			preparedStatement.setDate(4, new java.sql.Date(student.getReturn_date().getTime()));
			preparedStatement.setInt(5,student.getBook_id());
			preparedStatement.executeUpdate();
			return true;
			
		}
		
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		return false;
		
	}


}
