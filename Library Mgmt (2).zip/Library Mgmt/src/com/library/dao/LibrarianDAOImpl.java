package com.library.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.library.bean.Librarian;
import com.library.exception.LibrarianException;
import com.library.util.DBConnection;

public class LibrarianDAOImpl implements ILibrarianDAO{	
	
	Logger logger=Logger.getRootLogger();
	public LibrarianDAOImpl()
	{
	PropertyConfigurator.configure("Resources//log4j.properties");
	
	}
	
	
	@Override
	public String addBook(Librarian librarian) throws ClassNotFoundException, IOException, SQLException {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		String book_id=null;
		int queryResult;
	
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.addbooks);
			
			preparedStatement.setString(1,librarian.getBook_name());
			preparedStatement.setString(2, librarian.getBook_id());
			preparedStatement.setString(3, librarian.getBook_author());
			preparedStatement.setString(4, librarian.getDept_name());
			queryResult=preparedStatement.executeUpdate();
			Statement st=null;
			st=connection.createStatement();
			ResultSet resultset=null;
			resultset=st.executeQuery(QueryMapper.addbooks1);
			while(resultset.next())
			{
				//System.out.println(resultset.getString(1));
				book_id = resultset.getString(1);
			}
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new LibrarianException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return book_id;
			}

			}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new LibrarianException("Tehnical problem occured refer log");
		}
		
		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new LibrarianException("Error in closing db connection");

			}
			
			
			return book_id;
		}
		
	}
	

	@Override
	public Librarian viewBookDetails(int book_id) throws SQLException, IOException {
		Librarian librarian = new Librarian();
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		 try
		    {
			 preparedStatement=connection.prepareStatement(QueryMapper.viewbookdetails);
			 preparedStatement.setInt(1, book_id);
		      ResultSet rs = preparedStatement.executeQuery();
		      if(!rs.next()) {
		    	 return null;
		     }
		    
		     librarian.setBook_name(rs.getString(1));
		     librarian.setBook_id(rs.getString(2));
		     librarian.setBook_author(rs.getString(3));
		     librarian.setDept_name(rs.getString(4));
		    
		     if( librarian != null)
				{
					logger.info("Record Found Successfully");
					return librarian;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
		    }
		    
		    
		     catch(Exception e)
				{
					logger.error(e.getMessage());
					throw new LibrarianException(e.getMessage());
				}
				finally
				{
					try 
					{
						preparedStatement.close();
						connection.close();
					} 
					catch (SQLException e) 
					{
						logger.error(e.getMessage());
						throw new LibrarianException("Error in closing db connection");

					}
				}
		    
		return librarian;
	}
	
	

	@Override
	public List<Librarian> retrieveAll() throws SQLException, IOException {
		 List<Librarian> librarianList = new ArrayList<>();
		 Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=null;
		    try
		    {
		    	preparedStatement=connection.prepareStatement(QueryMapper.retrieveall);
			   ResultSet rs = preparedStatement.executeQuery();
		      while (rs.next())
		      {
		        Librarian librarian = new Librarian();
			    
			     librarian.setBook_name(rs.getString(1));
			     librarian.setBook_id(rs.getString(2));
			     librarian.setBook_author(rs.getString(3));
			     librarian.setDept_name(rs.getString(4));
			     librarianList.add(librarian);
		      }
		    }
		    catch (SQLException sqlException) {
		    	logger.error(sqlException.getMessage());
				throw new LibrarianException("Tehnical problem occured. Refer log");
		    }
		    finally
			{
				try 
				{
					rs.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new LibrarianException("Error in closing db connection");

				}
		    return librarianList.isEmpty()? null:librarianList;
	}
	
	
}
