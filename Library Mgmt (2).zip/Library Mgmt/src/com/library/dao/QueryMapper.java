package com.library.dao;

public interface QueryMapper {
	
	public static final String addbooks="insert into libmgmt values(?,?,?,?)";
	public static final String addbooks1="select * from libmgmt";
	public static final String viewbookdetails="select * from libmgmt where book_id=?";
	public static final String retrieveall="select * from libmgmt";
	public static final String addstudentdetails="insert into studentdetails values(?,?,?,?,?)";
	

}
