package com.library.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.library.bean.Librarian;
import com.library.dao.ILibrarianDAO;
import com.library.dao.LibrarianDAOImpl;
import com.library.exception.LibrarianException;

public class LibrarianServiceImpl implements ILibrarianService{
	
	ILibrarianDAO librariandao =new LibrarianDAOImpl();

	@Override
	public String addBook(Librarian librarian) throws ClassNotFoundException, IOException, SQLException  {	
	
		String librarianseq;
		librarianseq=librariandao.addBook(librarian);
		return librarianseq;
	}

	@Override
	public Librarian viewBookDetails(int book_id) throws IOException, SQLException {
		return librariandao.viewBookDetails(book_id);
	}

	@Override
	public List<Librarian> retrieveAll() throws IOException, SQLException {
		return librariandao.retrieveAll();
	}

	public void validateLibrarian(Librarian librarian) throws LibrarianException {
		
		List<String> validationErrors=new ArrayList<String>();
		
		if(!(isValidName(librarian.getBook_name())))
				{
			validationErrors.add("Name Should startwith Capital letter\n"
					+ "The minimum length should be 5 words\n");
				}
		
		if(!validationErrors.isEmpty())
			throw new LibrarianException(validationErrors +"");
		// TODO Auto-generated method stub
		
	}

	
	private boolean isValidName(String book_name)
	 	{
		Pattern pattern=Pattern.compile("^[A-Z][a-z]{5,}");
		Matcher nameMatcher=pattern.matcher(book_name);
		return nameMatcher.matches();
		// TODO Auto-generated method stub
		}

}
