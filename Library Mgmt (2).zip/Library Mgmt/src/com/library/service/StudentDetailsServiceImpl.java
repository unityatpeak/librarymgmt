package com.library.service;

import java.io.IOException;
import java.sql.SQLException;

import com.library.bean.Student;
import com.library.dao.StudentDetailsDAOImpl;

public class StudentDetailsServiceImpl implements StudentDetailsService {
	
	
	StudentDetailsDAOImpl studentDetailsDAOImpl =new StudentDetailsDAOImpl();
	@Override
	public Boolean addStudentDetails(Student student) throws ClassNotFoundException, IOException, SQLException {
		return studentDetailsDAOImpl.addStudentDetails(student);
		
	}

}
