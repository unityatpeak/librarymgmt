package com.library.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.library.bean.Librarian;
import com.library.dao.LibrarianDAOImpl;
import com.library.exception.LibrarianException;

public class LibrarianDAOTest {

	static LibrarianDAOImpl librariandao;
	static Librarian librarian;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		librariandao = new LibrarianDAOImpl();
		librarian = new Librarian();
	}

	//Test case for addbook()
	@Test
	public void testAddBook() throws LibrarianException, ClassNotFoundException, IOException, SQLException {

		assertNotNull(librariandao.addBook(librarian));

	}

	
	/* Test case for addBook()
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */

	@Ignore
	@Test
	public void testAddBook1() throws LibrarianException, ClassNotFoundException, IOException, SQLException {
		// increment the number next time you test for positive test case
		assertEquals(1001, librariandao.addBook(librarian));
	}

	/* Test case for addBook()
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 * @throws NumberFormatException 
	 */

	@Test
	public void testAddBook2() throws LibrarianException, NumberFormatException, ClassNotFoundException, IOException, SQLException {

		librarian.setBook_name("Socialstudies");
		librarian.setBook_id("1001");
		librarian.setBook_author("Herbert");
	    librarian.setDept_name("Social");
		assertNotNull("Data Inserted successfully");

	}
	
	
	
	//Test case for viewBookDetails()
	@Test
	public void testViewBookDetails() throws LibrarianException, SQLException, IOException
	{
		assertNotNull(librariandao.viewBookDetails(1000));
	}
	
	
	 /* Test case for retriveAll()
	 * @throws IOException 
	 * @throws SQLException */
	@Test
	public void testretrieveAll() throws LibrarianException, SQLException, IOException {
		assertNotNull(librariandao.retrieveAll());
	}


}
